<?php return [
    'plugin' => [
        'name' => 'Socializer',
        'description' => 'Add social activity on your site.',
        'option_description' => 'Options',
        'vk_api' => 'VK API',
    ],
];