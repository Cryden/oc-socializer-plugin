<?php return [
    'plugin' => [
        'name' => 'Соцпакет',
        'description' => 'Социальные сети на твоем сайте',
        'option_description' => 'Настройки',
        'vk_api' => 'VK API',
        'options_tab' => 'Опции',
    ],
];